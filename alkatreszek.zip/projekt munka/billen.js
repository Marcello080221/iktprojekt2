
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}

const products = [
    { id: 1, neve: "Redragon Kumara RGB", ár: "7 990 Ft", típus: "Billentyűzet", switchtípus: "Mechanical", szín: "RGB", model: "K552RGB-1REDHU" },
    { id: 2, neve: "SteelSeries Apex 3 TKL RGB UK", ár: "14 990 Ft", típus: "Billentyűzet", switchtípus: "Membrane", szín: "RGB", model: "64836" },
    { id: 3, neve: "Logitech G PRO GX Clicky", ár: "18 990 Ft", típus: "Billentyűzet", switchtípus: "Clicky", szín: "RGB", model: "920-009392" },
    { id: 4, neve: "Genius Scorpion K215", ár: "4 990 Ft", típus: "Billentyűzet", switchtípus: "Membrane", szín: "Black", model: "N/A" },
    { id: 5, neve: "Razer Huntsman Mini Red Switch US", ár: "34 990 Ft", típus: "Billentyűzet", switchtípus: "Opto-Mechanical", szín: "RGB", model: "RZ03-03390200-R3M1" },
    { id: 6, neve: "Cooler Master MK770 Red Switch", ár: "23 990 Ft", típus: "Billentyűzet", switchtípus: "Mechanical", szín: "RGB", model: "MK-770-GKKR1-HU" },
    { id: 7, neve: "Trust GXT 881 Odyss HU", ár: "8 990 Ft", típus: "Billentyűzet", switchtípus: "Mechanical", szín: "RGB", model: "24298" },
    { id: 8, neve: "ENDORFY Thock Kailh Brown HU", ár: "11 990 Ft", típus: "Billentyűzet", switchtípus: "Mechanical", szín: "RGB", model: "EY5E009" },
    { id: 9, neve: "Royal Kludge RKM75 RGB Silver", ár: "22 990 Ft", típus: "Billentyűzet", switchtípus: "Mechanical", szín: "RGB", model: "N/A" }
];

const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};

const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'típus', 'switchtípus', 'szín', 'model'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};

document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
