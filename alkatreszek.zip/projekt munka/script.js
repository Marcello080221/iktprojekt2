
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}

const products = [
    { id: 1, name: "ASUS ROG STRIX B650E-F GAMING WIFI", price: "104 690 Ft", socket: "AMD AM5", chipset: "AMD B650E", format: "ATX", memory: "DDR5, 4 modul, Dual-channel" },
    { id: 2, name: "ASUS TUF Gaming B550M-PLUS", price: "48 650 Ft", socket: "AMD AM4", chipset: "AMD B550", format: "mATX", memory: "DDR4, 4 modul, Dual-channel" },
    { id: 3, name: "MSI MAG B650 Tomahawk WIFI", price: "95 830 Ft", socket: "AMD AM5", chipset: "AMD B650", format: "ATX", memory: "DDR5, 4 modul, Dual-channel" },
    { id: 4, name: "MSI B550-A PRO", price: "48 920 Ft", socket: "AMD AM4", chipset: "AMD B550", format: "ATX", memory: "DDR4, 4 modul, Dual-channel" },
    { id: 5, name: "GIGABYTE B650 EAGLE AX", price: "69 990 Ft", socket: "AMD AM5", chipset: "AMD B650", format: "ATX", memory: "DDR5, 4 modul, Dual-channel" },
    { id: 6, name: "ASRock B550 Pro4 Alaplap", price: "48 390 Ft", socket: "AMD AM4", chipset: "AMD B550", format: "ATX", memory: "DDR4, 4 modul, Dual-channel" },
    { id: 7, name: "ASUS Prime B760-Plus Alaplap", price: "65 490 Ft", socket: "Intel LGA 1700", chipset: "Intel B760", format: "ATX", memory: "DDR4, 4 modul, Dual-channel" },
    { id: 8, name: "BIOSTAR B550MX/E Pro Alaplap", price: "37 790 Ft", socket: "AMD AM4", chipset: "AMD B550", format: "mATX", memory: "DDR4, 4 modul, Dual-channel" },
    { id: 9, name: "GIGABYTE X870I AORUS PRO ICE Alaplap", price: "165 691 Ft", socket: "Intel LGA 1700", chipset: "Intel Z870", format: "ITX", memory: "DDR5, 2 modul, Dual-channel" }
];

const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.name, product.id);
            dropdown.add(option);
        });
    });
};

const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['name', 'price', 'socket', 'chipset', 'format', 'memory'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);