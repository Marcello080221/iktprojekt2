
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}



const products = [
    { id: 1, neve: "Kingston FURY Beast 32GB (2x16GB) DDR4 3200MHz", ár: "30 000 Ft", model: "KF432C16BB1K2/32", típus: "DDR4", kapacitás: "32GB", sebesség: "3200MHz" },
    { id: 2, neve: "G.SKILL Flare X5 32GB (2x16GB) DDR5 6000MHz", ár: "53 000 Ft", model: "F5-6000J3038F16GX2-FX5", típus: "DDR5", kapacitás: "32GB", sebesség: "6000MHz" },
    { id: 3, neve: "Silicon Power XPower Pulse 32GB (2x16GB) DDR4 3200MHz", ár: "25 000 Ft", model: "SP032GXLZU320BDI", típus: "DDR4", kapacitás: "32GB", sebesség: "3200MHz" },
    { id: 4, neve: "Kingston FURY Renegade 32GB (2x16GB) DDR4 3600MHz", ár: "33 000 Ft", model: "KF436C16RB12K2/32", típus: "DDR4", kapacitás: "32GB", sebesség: "3600MHz" },
    { id: 5, neve: "Kingston FURY Beast RGB 32GB (2x16GB) DDR5 6000MHz", ár: "56 000 Ft", model: "KF560C30BBAK2-32", típus: "DDR5", kapacitás: "32GB", sebesség: "6000MHz" },
    { id: 6, neve: "Hikvision HIKSEMI 8GB DDR3 1600MHz", ár: "4 300 Ft", model: "HS-DIMM-S1(STD)/HSC308S16Z1/HIKER/W", típus: "DDR3", kapacitás: "8GB", sebesség: "1600MHz" },
    { id: 7, neve: "Crucial 16GB DDR4 3200MHz", ár: "13 300 Ft", model: "CT16G4SFRA32A", típus: "DDR4", kapacitás: "16GB", sebesség: "3200MHz" },
    { id: 8, neve: "Patriot Viper Venom 32GB (2x16GB) DDR5 6000MHz", ár: "40 000 Ft", model: "PVV532G600C36K", típus: "DDR5", kapacitás: "32GB", sebesség: "6000MHz" },
    { id: 9, neve: "G.SKILL Trident Z Neo 32GB (2x16GB) DDR4 3600MHz", ár: "43 000 Ft", model: "F4-3600C16D-32GTZNC", típus: "DDR4", kapacitás: "32GB", sebesség: "3600MHz" }
];




const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};


const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'model', 'típus', 'kapacitás', 'sebesség'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
