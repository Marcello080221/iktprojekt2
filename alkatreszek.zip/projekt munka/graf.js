
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}



const products = [
    { id: 1, neve: "ASUS GeForce RTX 4060 Dual EVO OC 8GB GDDR6 128bit", ár: "141 320 Ft", Lapkakészlet: "NVIDIA GeForce RTX 4060", memória: "8GB GDDR6", típus: "Videokártya" },
    { id: 2, neve: "SAPPHIRE AMD Radeon RX 7900 XT NITRO+ 20GB GDDR6", ár: "365 990 Ft", Lapkakészlet: "AMD Radeon RX 7900 XT", memória: "20GB GDDR6", típus: "Videokártya" },
    { id: 3, neve: "MSI RTX 4090 Ventus 3X E 24G OC GDDR6X", ár: "1 199 990 Ft", Lapkakészlet: "NVIDIA GeForce RTX 4090", memória: "24GB GDDR6X", típus: "Videokártya" },
    { id: 4, neve: "ASUS GeForce RTX 3060 12GB Dual V2 OC GDDR6 192bit", ár: "139 990 Ft", Lapkakészlet: "NVIDIA GeForce RTX 3060", memória: "12GB GDDR6", típus: "Videokártya" },
    { id: 5, neve: "GIGABYTE Radeon RX 7600 XT Gaming OC 16GB GDDR6", ár: "149 990 Ft", Lapkakészlet: "AMD Radeon RX 7600 XT", memória: "16GB GDDR6", típus: "Videokártya" },
    { id: 6, neve: "SAPPHIRE PULSE AMD Radeon RX 7600 8GB", ár: "139 990 Ft", Lapkakészlet: "AMD Radeon RX 7600", memória: "8GB GDDR6", típus: "Videokártya" },
    { id: 7, neve: "XFX Radeon Speedster SWFT 210 RX 7800 XT Core 16GB GDDR6", ár: "339 990 Ft", Lapkakészlet: "AMD Radeon RX 7800 XT", memória: "16GB GDDR6", típus: "Videokártya" },
    { id: 8, neve: "Inno3D GeForce RTX 4080 Super 3X 16GB", ár: "1 179 990 Ft", Lapkakészlet: "NVIDIA GeForce RTX 4080", memória: "16GB GDDR6X", típus: "Videokártya" },
    { id: 9, neve: "Intel Arc B580 Limited Edition", ár: "129 990 Ft", Lapkakészlet: "Intel Arc B580", memória: "8GB GDDR6", típus: "Videokártya" }
];




const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};


const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'Lapkakészlet', 'memória', 'típus'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
