
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}



const products = [
    { id: 1, neve: "AMD Ryzen 7 9800X3D Box", ár: "259 990 Ft", foglalat: "AM5", magokszáma: 8, órajelsebesség: "nem elérhető", hűtés: "Box" },
    { id: 2, neve: "AMD Ryzen 5 3600 6-Core 3.6GHz AM4 Box", ár: "32 475 Ft", foglalat: "AM4", magokszáma: 6, órajelsebesség: "3.6 GHz", hűtég: "Box, Fan & Heatsink" },
    { id: 3, neve: "Intel Core i5-12400F 6-Core 2.5GHz LGA1700", ár: "50 750 Ft", foglalat: "LGA1700", magokszáma: 6, órajelsebesség: "2.5 GHz", hűtés: "nem elérhető" },
    { id: 4, neve: "AMD Ryzen 5 5500 6-Core 3.6 GHz AM4 Box", ár: "38 995 Ft", foglalat: "AM4", magokszáma: 6, órajelsebesség: "3.6 GHz", hűtés: "Box" },
    { id: 5, neve: "Intel Core i9-14900K 24-Core 3.2GHz LGA1700 Box", ár: "227 370 Ft", foglalat: "LGA1700", magokszáma: 24, órajelsebesség: "3.2 GHz", hűtés: "Box" },
    { id: 6, neve: "Intel Core i5-14600K 14-Core 3.4GHz LGA1700 Box", ár: "106 020 Ft", foglalat: "LGA1700", magokszáma: 14, órajelsebesség: "3.4 GHz", hűtés: "Box" },
    { id: 7, neve: "AMD Ryzen 9 5900X 12-Core 3.7GHz AM4 Box without fan and heatsink", ár: "98 680 Ft", foglalat: "AM4", magokszáma: 12, órajelsebesség: "3.7 GHz", hűtés: "nem elérhető" },
    { id: 8, neve: "Intel Core i7-14700K 3.4GHz Box", ár: "174 030 Ft", foglalat: "LGA1700", magokszáma: 8, órajelsebesség: "3.4 GHz", hűtés: "Box" },
    { id: 9, neve: "Intel Core i3-12100F 4-Core 3.3GHz LGA1700 Box", ár: "34 390 Ft", foglalat: "LGA1700", magokszáma: 4, órajelsebesség: "3.3 GHz", hűtés: "Box" }
];




const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};


const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'foglalat', 'magokszáma', 'órajelsebesség', 'hűtés'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
