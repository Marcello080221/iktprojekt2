
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}



const products = [
    { id: 1, neve: "Logitech G305 Lightspeed Black", ár: "13 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezeték_nélküli", senzor: "Hero senzor", DPI: "12,000" },
    { id: 2, neve: "SteelSeries Rival 3", ár: "7 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "TrueMove Core", DPI: "8,500" },
    { id: 3, neve: "Razer Basilisk V3", ár: "21 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "Focus+ Optical senzor", DPI: "26,000" },
    { id: 4, neve: "Glorious PC Gaming Race Model O Matte Black", ár: "16 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "Pixart 3360", DPI: "12,000" },
    { id: 5, neve: "Logitech G502 X Black", ár: "21 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "Hero 25K", DPI: "25,600" },
    { id: 6, neve: "Apple Magic Mouse 3", ár: "24 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezeték_nélküli", senzor: "Laser", DPI: "N/A" },
    { id: 7, neve: "ASUS ROG Gladius III vezeték_nélküli AimPoint Black", ár: "29 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezeték_nélküli", senzor: "ROG AimPoint Optical", DPI: "36,000" },
    { id: 8, neve: "LAMZU Atlantis M305", ár: "14 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "Pixart 3389", DPI: "16,000" },
    { id: 9, neve: "A4Tech Bloody V7m", ár: "6 990 Ft", típus: "Egér", Vezetékes_Vezetéknélküli: "vezetékes", senzor: "Optical", DPI: "3,200" }
];




const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};


const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'típus', 'Vezetékes_Vezetéknélküli', 'senzor', 'DPI'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
