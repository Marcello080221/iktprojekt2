
function showDetails(button) {
    const details = button.nextElementSibling;
    if (details.hidden) {
        details.hidden = false;
        button.textContent = "Kevesebb leírás";
    } else {
        details.hidden = true; 
        button.textContent = "További leírás";
    }
}
function goBack() {
    window.history.back();
}



const products = [
    { id: 1, neve: "Kingston NV2 1TB M.2 PCIe NVMe", ár: "17 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "M.2 PCIe NVMe" },
    { id: 2, neve: "Samsung 990 PRO 1TB M.2 NVMe", ár: "54 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "M.2 NVMe" },
    { id: 3, neve: "Western Digital Blue SN580 1TB M.2", ár: "26 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "M.2" },
    { id: 4, neve: "Seagate BarraCuda 3.5 8TB 5400rpm 256MB SATA3", ár: "64 990 Ft", típus: "HDD", kapacitás: "8TB", felület: "SATA3", rpm: "5400" },
    { id: 5, neve: "Kingston A400 2.5 480GB SATA3", ár: "14 990 Ft", típus: "SSD", kapacitás: "480GB", felület: "SATA3" },
    { id: 6, neve: "Samsung 970 EVO Plus 1TB M.2 PCIe", ár: "43 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "M.2 PCIe" },
    { id: 7, neve: "Crucial BX500 2.5 1TB SATA3", ár: "22 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "SATA3" },
    { id: 8, neve: "Dahua C800A 2.5 128GB SATA3", ár: "5 990 Ft", típus: "SSD", kapacitás: "128GB", felület: "SATA3" },
    { id: 9, neve: "Team Group MP44L 1TB M.2", ár: "26 990 Ft", típus: "SSD", kapacitás: "1TB", felület: "M.2" }
];




const populateDropdowns = () => {
    const dropdowns = [document.getElementById('product1'), document.getElementById('product2')];
    products.forEach(product => {
        dropdowns.forEach(dropdown => {
            const option = new Option(product.neve, product.id);
            dropdown.add(option);
        });
    });
};


const compareProducts = () => {
    const id1 = document.getElementById('product1').value;
    const id2 = document.getElementById('product2').value;

    if (!id1 || !id2) return alert('Kérlek, válassz ki két terméket!');

    const [product1, product2] = [products.find(p => p.id == id1), products.find(p => p.id == id2)];
    const tbody = document.querySelector('#comparison-table tbody');
    tbody.innerHTML = ''; 

    ['neve', 'ár', 'típus', 'kapacitás', 'felület'].forEach(param => {
        tbody.innerHTML += `
            <tr>
                <td>${param[0].toUpperCase() + param.slice(1)}</td>
                <td>${product1[param]}</td>
                <td>${product2[param]}</td>
            </tr>`;
    });
};


document.addEventListener('DOMContentLoaded', populateDropdowns);
document.getElementById('compare-button').addEventListener('click', compareProducts);
